package com.cg.mobilebilling;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CgMobileBillingPortalSpringBootMvcjpadata1Application {

	public static void main(String[] args) {
		SpringApplication.run(CgMobileBillingPortalSpringBootMvcjpadata1Application.class, args);
	}

}
